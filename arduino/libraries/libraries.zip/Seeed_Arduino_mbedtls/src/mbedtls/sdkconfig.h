/*

    Automatically generated file; DO NOT EDIT.
    Espressif IoT Development Framework Configuration

*/
#ifndef  SEEED_ATSDK_CONFIG
#define  SEEED_ATSDK_CONFIG

#define CONFIG_MBEDTLS_AES_C

#endif //SEEED_ATSDK_CONFIG
