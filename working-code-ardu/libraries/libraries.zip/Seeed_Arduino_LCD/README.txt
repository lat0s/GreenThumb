This is a standalone library that contains both graphics functions
and the TFT chip driver library.

This library has been derived from the Adafruit_GFX and driver library with
further code from other authors.

It is not compatible with legacy versions of the IDE (e.g. 1.0.6 and
older. Use the latest version.

New functions have been added in particular it contains proportional fonts
in addition to the original Adafruit font.

A sprite class has been added to aid the generation of flicker free complex
graphics.

Note: This version of the library might not be fully compatible with the
original.

